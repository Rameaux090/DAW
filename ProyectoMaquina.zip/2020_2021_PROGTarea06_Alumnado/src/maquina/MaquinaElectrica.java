
package maquina;

/**
 *Clase que representa un subtipo de Máquinas, las Máquinas elécricas. A la información heredada de la clase Maquina, añade un par de atributos:
  Voltaje. Es el voltaje de esta máquina eléctrica. Expresado en voltios (v.)
  Potencia eléctrica. Es la potencia eléctrica de una máquina. Expresada en kilowatios (kW.) eléctrica.
 * @author Cristian Ramos Rodríguez.
 */
public abstract class MaquinaElectrica extends Maquina {
    
        public static final int DEFAULT_VOLTAJE = 10;
        public static final int MIN_VOLTAJE = 10;
        public static final int MAX_VOLTAJE = 400;
        public static final double DEFAULT_POTENCIA_ELECTRICA = 700.0;
        public static final double MIN_POTENCIA_ELECTRICA = 700.0;
        public static final double MAX_POTENCIA_ELECTRICA = 200000.0;
        
        protected int voltaje;
        protected double potenciaElectrica;
        
     /**
      * Constructor para objetos de tipo Maquinaelectrica, a partir de los atributos marca, modelo, voltaje y potencia eléctrica. El constructor verifica que 
      * los valores suministrados como parámetro para voltaje y potenciaElectrica sean válidos.
      * @param marca  La marca de la máquina.
      * @param modelo El modelo de la máquina.
      * @param voltaje  El voltaje de la máquina. Debe estar entre el mínimo de 10 v. y el máximo de 400 v. (para corriente trifásica).
      * @param potenciaElectrica La potencia eléctrica de la máquina. No puede ser negativa, ni superar los 200000.0 kW.
      */  
      public MaquinaElectrica (String marca,String modelo,int voltaje,double potenciaElectrica) throws IllegalArgumentException {
          super(marca,modelo);
          this.voltaje = voltaje;
          this.potenciaElectrica = potenciaElectrica;
          if(voltaje < MIN_VOLTAJE || voltaje > MAX_VOLTAJE){
              throw new IllegalArgumentException ("Error de voltaje: " + voltaje +"v" + " Mínimo "+ MIN_VOLTAJE + "v"+ " máximo " + MAX_VOLTAJE+"v.");
          }
          if(potenciaElectrica < MIN_POTENCIA_ELECTRICA || potenciaElectrica > MAX_POTENCIA_ELECTRICA) {
              throw new IllegalArgumentException ("Error de potencia: " + potenciaElectrica +" No puede ser menor que" + MIN_POTENCIA_ELECTRICA +" w. ni superar los"
                      + MAX_POTENCIA_ELECTRICA + " w.");
            }
      }
    /**
     * 
     * @param marca
     * @param modelo 
     */  
    public MaquinaElectrica(String marca,String modelo) {
        super(marca, modelo);
          int defaultVoltaje = MaquinaElectrica.DEFAULT_VOLTAJE;
          double defaultPotenciaElectrica = MaquinaElectrica.DEFAULT_POTENCIA_ELECTRICA;
         
    }
    
    /**
     * 
     * @return 
     */
    public int getVoltaje(){
        return voltaje;
    }
    
    /**
     * 
     * @return 
     */
    public double getPotenciaElectrica() {
        return potenciaElectrica;
    }
    
    /**
     * 
     * @return 
     */
    @Override
        public String toString() {
            String toStringSuper = super.toString();
            return String.format("%s; Voltaje: %-10ds v Potencia: %s w.}",
                toStringSuper.substring(0, toStringSuper.length() - 2),
               this.getVoltaje() , this.getPotenciaElectrica());
        }
    
}
