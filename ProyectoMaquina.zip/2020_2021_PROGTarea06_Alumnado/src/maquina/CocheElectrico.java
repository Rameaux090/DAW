
package maquina;

import java.util.Arrays;

/**
 * Clase que modela un tipo especial de coche: un coche eléctrico. Con capacidad de ser enchufado, con una batería recargable, y con capacidad para desplazarse.
 * Añade a la clase Coche de la que hereda, los atributos siguientes:
Voltaje de la batería. Valores válidos serán: 12V en España y Portugal, 24V en Francia y Bélgica y 48V en Inglaterra.
Capacidad máxima de la batería. Valores válidos (en kWh) serán: 35, 50, 75, 100, 125, 150, 200.
Carga efectiva. La cantidad de carga que se estima que queda en el Coche eléctrico. En futuras versiones, la carga efectiva se calculará en función de los km 
* recorridos y de la autonomía del vehículo.
* 
 * @author Cristian Ramos Rodríguez
 */
public final  class CocheElectrico extends Coche implements Recargable, Enchufable {    
    /**Capacidad máxima por defecto de la batería de un Coche Eléctrico: 100.0 KiloWatios-Hora.(kWh)
     * 
     */
    public static final double DEFAULT_CAPACIDAD_MAXIMA_BATERIA = 100 ;
    /**
     * 
     * Potencia por defecto de un Coche Eléctrico: 100000 kiloWatios (kW)
     */
    public static final int DEFAULT_POTENCIA = 100000 ;
    /**
     * Carga efectiva por defecto para un Coche Eléctrico. Se entiende que la carga efectiva va a ser siempre la mitad de la capacidad máxima de la batería,
     * por lo que los coches saldrán de fábrica siempre con la batería a media carga. Valor: 50.0 KiloWatios-Hora.(kWh)
     */
    public static final double DEFAULT_CARGA_EFECTIVA = 50.0;
    
    
    /**
     * La autonomía mínima permitida que se podrá asignar a un Coche Eléctrico. Valor: 300.0 kilómetros (km).
     */
    public static final double MIN_AUTONOMIA = 300.0;
    /**
     * La autonomía máxima que se podrá asignar a un Coche Eléctrico, con las limitaciones técnicas actuales. Valor:600.0 kilómetros (km).
     */
    public static final double MAX_AUTONOMIA = 600.0;
    
    protected  int voltajeBateria;
    protected  double capacidadMaximaBateria;
    protected double cargaEfectiva;
    protected double autonomia;
    
    /**
     * Array que en cada fila establece los países que comparten un determinado
     * voltaje estándar. Cada fila por tanto, corresponderá a un voltaje
     * estándar diferente. Este listado se usa internamente por la clase, por lo
     * que no es necesario que sea público.
     *
     */
    private final static String[][] LISTA_PAISES_COMPATIBLES =  {
        {"España", "Portugal"}, // 12 v.
        {"Francia", "Bélgica"}, // 24 v.
        {"Inglaterra"} // 48 v.
           
    };
    
    /**
     * Este constructor crea un coche eléctrico a partir de los parámetros marca, modelo y fuerzaMotriz que recibe, y asigna a voltaje de la batería y a capacidad de
     * la batería los valores por defecto. Para la autonomía se usa como valor por defecto el valor mínimo permitido.
     * @param marca
     * @param modelo
     * @param fuerzaMotriz
     * @throws IllegalArgumentException Cuando se intenta asignar como fuerza motriz un valor diferente de ELECTRICIDAD.
     * @throws NullPointerException 
     */
    public CocheElectrico(String marca, String modelo,Fuerza fuerzaMotriz ) throws IllegalArgumentException,NullPointerException {
        super(marca,modelo,fuerzaMotriz);
            this.capacidadMaximaBateria = DEFAULT_CAPACIDAD_MAXIMA_BATERIA;
            this.voltajeBateria = DEFAULT_POTENCIA ;
            this.autonomia = MIN_AUTONOMIA;
                if(fuerzaMotriz == null || fuerzaMotriz != Fuerza.ELECTRICIDAD) {
                    throw new IllegalArgumentException("Error en fuerza Motriz:" + fuerzaMotriz + ". Para un coche eléctrico debe ser necesariamente" +
                    Fuerza.ELECTRICIDAD +".");
                  }
        
    }
    
    /**
     * Constructor público de la clase CocheElectrico.Crea un nuevo Coche Eléctrico a partir de los datos recibidos como parámetros (marca, modelo, fuerza Motriz,
     * voltaje de la batería y capacidad máxima de la batería). Como capacidad efectiva de carga, a la salida de fábrica, la batería siempre irá a media carga respecto
     * a su capacidad máxima
     * @param marca
     * @param modelo
     * @param fuerzaMotriz
     * @param voltajeBateria
     * @param capacidadMaximaBateria
     * @param autonomia
     * @throws IllegalArgumentException
     * @throws NullPointerException 
     */
    public CocheElectrico(String marca, String modelo ,Fuerza fuerzaMotriz,int voltajeBateria,double capacidadMaximaBateria,double autonomia)
            throws IllegalArgumentException,NullPointerException  {
                   super(marca,modelo,fuerzaMotriz);
                   
                        if(fuerzaMotriz == null){
                           throw new NullPointerException ("Error: null. La fuerza motriz no puede ser nula, debe indicarse una fuerza motriz válida");
                         }
                        if(voltajeBateria != 12 || voltajeBateria != 24 || voltajeBateria !=48 || capacidadMaximaBateria != 35 || capacidadMaximaBateria != 50 || 
                                capacidadMaximaBateria != 75 || capacidadMaximaBateria != 100 || capacidadMaximaBateria != 125 || capacidadMaximaBateria != 150 || 
                                capacidadMaximaBateria != 125 || autonomia < MIN_AUTONOMIA || autonomia > MAX_AUTONOMIA) {
                            
                                 throw new IllegalArgumentException("Error en voltaje de la Bateria:" + voltajeBateria + "Capacidad Bateria:" + capacidadMaximaBateria +
                                         " Autonomia: " + autonomia + " MAX: " + MAX_AUTONOMIA + " MIN: " + MIN_AUTONOMIA );
                                 
                        }
                   
    }
    
    /**
     * Método de consulta que permite obtener el tipo de combustible usado por un Coche Eléctrico.
     * @return 
     */
    @Override
    public TipoCombustible getTipoCombustible() {
        return this.combustibleUsado;
    }
    
    /**
     * Método que comprueba en primer lugar si la carga efectiva de la batería permitiría un desplazamiento de la cantidad de kilómetros indicados como parámetro. 
     * Si hay batería suficiente, desplaza el coche esos kilómetros, actualizando el total de kilómetros recorridos, los kilómetros recorridos sin repostar, y la
     * carga efectiva restante en la batería
     * @param kilometros
     * @throws IllegalArgumentException 
     */
    
    @Override
    public void desplazar​(double kilometros) throws IllegalArgumentException {
        this.cargaEfectiva = DEFAULT_CARGA_EFECTIVA;
    }
    
    /**
     * Método que permite cargar la batería de un Coche Eléctrico, estableciendo su carga efectiva al valor de la capacidad máxima de su batería. Tras cargar la batería,
     * los kilómetros sin repostar se inicializan a 0.
     */
    @Override
    public void cargar() {
        this.cargaEfectiva = DEFAULT_CAPACIDAD_MAXIMA_BATERIA;
        this.kilometrosSinRepostar = super.kilometrosSinRepostar;
    }
    /**
     * 
     * @param kilometros
     * @return 
     */
    @Override
    public double usarBateria​(double kilometros) {
        
    }
    
    /**
     * Método de consulta que devuelve el voltaje de la batería del Coche Eléctrico.
     * @return 
     */
    @Override
    public int getVoltaje() {
        return this.voltajeBateria;
    }
    /**
     * 
     * @return 
     */
    @Override
    public String[] getPaisesCompatibles() {
        
    }
    
    @Override
        public String toString() {
            String toStringSuper = super.toString();
            return String.format("%s; Kilometraje: %-10ds Km Voltaje: %d;  Capacidad Bateria: %d; Autonomia: %d; Carga Efectiva: %d; Paises Compatibles: %s }",
                toStringSuper.substring(0, toStringSuper.length() - 2),
               this.getTotalKilometrosRecorridos() ,this.getVoltaje(),this.usarBateria(autonomia),this.autonomia, this.cargaEfectiva,
               Arrays.toString(this.getPaisesCompatibles()));
        }
}
