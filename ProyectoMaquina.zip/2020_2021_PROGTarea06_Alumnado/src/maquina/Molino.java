
package maquina;

/**
 *Clase que representa un tipo de máquina mecánica, un Molino. Define internamente un enumerado Tipo, con los posibles valores para el atributo tipo de molino en 
 * función de cuál sea la fuerza motriz que usa para funcionar. No se desea permitir que esta clase se extienda en el futuro, por lo que se impide la creación de subclases.
 * @author Cristian Ramos Rodríguez.
 */
public class Molino extends MaquinaMecanica {
   
     protected TipoMolino tipoMolino;
     /**
      * Constructor que crea un nuevo Molino a partir de los valores recibidos mediante los parámetros marca, modelo y fuera motriz, haciendo uso del constructor. 
      * El tipo de molino se asigna en función de la fuerza motriz de dicho molino para que sea congruente.
      * @param marca
      * @param modelo
      * @param fuerzaMotriz
      * @throws IllegalArgumentException
      * @throws NullPointerException 
      */
    public Molino(String marca, String modelo, Fuerza fuerzaMotriz) throws IllegalArgumentException,NullPointerException {
        super(marca, modelo, fuerzaMotriz);
        
        if(fuerzaMotriz == null ) {
            throw new NullPointerException ("Error, Fuerza motriz no válida:" + fuerzaMotriz);
        }
    }
    
    /**
     * Método que permite obtener el tipo de molino de que se trata.
     * @return La representación como String del tipo de Molino.
     */
    public TipoMolino getTipoDeMolino() {
        return tipoMolino;
    }
    /**
     * Método que devuelve la representación como String de una máquina mecánica.
     * @return 
     */
    @Override
        public String toString() {
            String toStringSuper = super.toString();
            return String.format("%s; Molino de: %s }",
                toStringSuper.substring(0, toStringSuper.length() - 2),
               this.getTipoDeMolino());
        }
}
