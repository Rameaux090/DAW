
/**
 * Proporciona las clases de prueba para las clases del paquete <code>maquina</code>.
 * Incorpora la clase <code>PruebaMaquina</code>.
 * 
 * @author Profesor PROG
 */
package pruebamaquina;