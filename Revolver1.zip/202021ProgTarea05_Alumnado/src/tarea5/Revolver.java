package tarea5;
import libtarea5.Audio;
import java.time.LocalDate;

// ------------------------------------------------------------
//                   Clase Revolver
// ------------------------------------------------------------
/**
 * Clase que representa un <strong>revolver</strong>.
 *
 *Los objetos de esta clase permiten almacenar y gestionar información sobre:
 * 
 *<strong>Número de serie</strong> del revolver. Este valor se establecerá al crear el objeto revolver y ya no podrá cambiar. Es un valor constante.
 * 
 *<strong>Tambor del revolver</strong>: balas y casquillos que contiene en cada momento el tambor del revolver,así como su disposición en el tambor
 *y qué orificio del tambor está en cada momento ante el percutor para recibir el impacto al apretar el gatillo del arma.
 * 
 *<strong>Disparos efectivos</strong> realizados por el revolver a lo largo de su historia.
 *
 *La clase también dispone de información general independiente de los objetos concretos que se hayan creado. Es el caso de:
 *<strong>Número de disparos totales</strong> realizados por todos los revólveres hasta el momento actual.
 *<strong>Número de revólveres descargados</strong> en el momento actual.
 *
 * @author Cristian Ramos Rodríguez.
 */
public class Revolver {
    // ------------------------------------------------------------
    //                 ATRIBUTOS ESTÁTICOS (de clase)
    // ------------------------------------------------------------
    
    /**
     * Atributos estáticos constantes públicos (rangos y requisitos de los atributos de objeto)
     */
    /**
     * Mínima capacidad del tambor permitida a la hora de crear un nuevo revólver: 5 balas.
     */
     public static final int MINIMA_CAPACIDAD = 5;
     /**
      * Máxima capacidad del tambor permitida a la hora de crear un nuevo revólver: 10 balas.
      */
     public static final int MAXIMA_CAPACIDAD = 10; 
     /**
      * Valor por omisión para la capacidad del tambor de un nuevo revólver 6 balas.
      */
     public static final int DEFAULT_CAPACIDAD = 6;
     /**
      * Último número de serie que se puede crear por año 99.
      */
     public static final int MAXIMO_NUM_SERIE = 99;
     
    // ATRIBUTOS DE CLASE
   // ------------------
   private static final StringBuilder NUM_SERIE= new StringBuilder();
    
   // Atributos de clase variables 
  
    private   int id= 1;  // Inicio de secuencia
   
    // ------------------------------------------------------------
    //                ATRIBUTOS DE OBJETO (privados)
    // ------------------------------------------------------------
    
  private final Integer [] tamborRevolver;
  private int posicion;
 
    
  // Atributos de objeto variables
  // Representan el "estados" de la clase en un instante dado.
  private int disparosEfectivos;
  
  // Atributos variables (privados: "estado" de la clase)
  private static int numTotalDisparos;
   private static int revolverDescargados; 
  
  
    // ------------------------------------------------------------
    //                        CONSTRUCTORES
    // ------------------------------------------------------------
 
  /**
   * Constructor basado en la capacidad del tambor.
   * Crea un nuevo objeto <strong>Revolver</strong> con el tamaño de tambor indicado en el parámetro.
   * @param capacidad
   * @throws java.lang.IllegalArgumentException
   * @throws java.lang.IllegalStateException 
   */ 
  
   public Revolver(int capacidad)throws java.lang.IllegalArgumentException,
                java.lang.IllegalStateException  {   
     // Creamos la fecha del momento de la creacion.
      LocalDate fechaCreacion = LocalDate.now();
      //Añadimos el año a la variable StringBuilder NUM_SERIE y un "-"
   NUM_SERIE.append(fechaCreacion.getYear());
   NUM_SERIE.append("-");
   // Si el valor de id es menor que 10, se le añade un 0 delante en la cadena.
   if(id<10) {
       NUM_SERIE.append("0");
       NUM_SERIE.append(id);
       id++;
   }
   // Si es superior a 9, no se le añade ningun 0.
   else if(id>9){
         NUM_SERIE.append(id);
         id++;
   
   }if (id>MAXIMO_NUM_SERIE) {
       throw new IllegalStateException("Se ha alcanzado  la cantidad máxima de registros que se pueden crear este año "+ fechaCreacion +":"+ id);
       
   }if (capacidad>MAXIMA_CAPACIDAD || capacidad < MINIMA_CAPACIDAD)  {
        
       throw new IllegalArgumentException("Parámetros de creación del revólver inválidos. Capacidad del tambor: " + capacidad);
   }else {
       tamborRevolver = new Integer [capacidad];
   }
   
    for(int i = 0; i<capacidad;i++) {
        tamborRevolver[i] = null;
    }
   id++;
 }
  //----------------------------------
 // CONTRUCTOR COPIA CON UN PARÁMETRO.
 //--------------------------------
/**
 * Constructor copia. Crea un nuevo objeto <strong>Revolver</strong> con las mismas características 
 * que el que se ha pasado como parámetro. El nuevo objeto tendrá el tambor vacío y
 * un nuevo número de serie.
 * @param r
 * @throws IllegalStateException 
 */
 public Revolver(Revolver r) throws IllegalStateException {
     this.tamborRevolver = null;
     this.setPosicion(r.getPosicion());
 }
 
  //----------------------------------
 // CONSTRUCTOR SIN PARÁMETROS.
 //----------------------------------
 /**
  * Constructor sin parámetros. Crea un nuevo objeto <strong>Revolver</strong> con el tamaño de tambor por omisión. 
  * El tamaño por omisión para el tambor es de 6 balas.
  * @throws IllegalStateException 
  */
 public Revolver()throws IllegalStateException {   
     this (Revolver.DEFAULT_CAPACIDAD);
 }
 
  //----------------------------------
 //  METODOS "FABRICA".
//----------------------------------
 /**
  * Método "fábrica" creador de un revolver ya cargado. Crea un nuevo objeto <strong>Revolver</strong> con el tamaño de tambor indicado 
  * en el parámetro y cargado de balas.
  * @param capacidad
  * @return
  * @throws IllegalArgumentException
  * @throws IllegalStateException 
  */
 
 // TIENE ERRORES.
// public static Revolver crearRevolverCargado​(int capacidad) throws IllegalArgumentException, IllegalStateException {
//   
//
//   if(NUM_SERIE > Revolver.MAXIMA_CAPACIDAD){
//        throw new IllegalStateException("Se ha alcanzado  la cantidad máxima de registros que se pueden crear este año "+ fechaCreacion +":"+ id);
//   }
//   
//   if (capacidad>MAXIMA_CAPACIDAD || capacidad < MINIMA_CAPACIDAD)  {
//        
//       throw new IllegalArgumentException("Parámetros de creación del revólver inválidos. Capacidad del tambor: " + capacidad);
//   }else {    
//     tamborRevolver = new Integer [capacidad];  
//   }
//   for(int i = 0; i <capacidad;i++){
//       
//       tamborRevolver[i]= 1;
//   }
//    
//   return capacidad;
// }
 
 // ESTE PIENSO QUE SI NO HAGO BIEN EL ANTERIOR NO PUEDO DECLARARLO.
 /**
  * 
  * @return
  * @throws IllegalStateException 
  */
// public static Revolver crearRevolverCargado() throws IllegalStateException {
//     
//     return
// }
 
    // ------------------------------------------------------------
    //                 Getters:  Métodos GET
    // ------------------------------------------------------------
 /**
  * Obtiene el número de serie del revólver.
  * @return 
  */
 public int getNumSerie(){
     return this.id;
 }
/**
 * Obtiene la capacidad del tambor del revólver.
 * @return 
 */ 
public int getCapacidad() {
    return this.tamborRevolver.length;
}

public int getNumBalas() {
    return this.tamborRevolver.length;
}

/**
 * Indica si el revólver se encuentra totalmente descargado.
 * @return 
 */
public boolean isDescargado() {
    Boolean vacio = true;
        for(int i=0;i<this.tamborRevolver.length;i++){
	    if(this.tamborRevolver[i].equals(1)){
				//hay balas
				vacio = false;
	    }
	}
	return vacio;
}
    
public int getNumDisparos() {
 return this.disparosEfectivos;
}

/**
 * Devuelve la posicion de el tambor.
 * @return 
 */
public int getPosicion() {
		return posicion;
	}
/**
 * 
 * @param posicion 
 */	
public void setPosicion(int posicion) {
		this.posicion = posicion;
	}


    // ------------------------------------------------------------
    //                MÉTODOS DE CONSULTA ESTÁTICOS.
    // ------------------------------------------------------------

/**
 * Devuelve la cantidad de disparos efectivos realizados por todos los revólveres hasta el momento.
 * @return 
 */

public static int getNumTotalDisparos() {
    return Revolver.numTotalDisparos;
}

/**
 * Devuelve la cantidad de revólveres descargados que hay en el momento actual.
 * @return 
 */
public static int getNumRevolveresDescargados() {
    return Revolver.revolverDescargados;
}


 // ------------------------------------------------------------
 //                MÉTODOS DE ACCIÓN.
 // ------------------------------------------------------------



public int cargar​(int numBalas) throws IllegalArgumentException {
	int contadorCargadas  = 0;
	if(numBalas < 0){
		throw new IllegalArgumentException("Pon error");
	}
	for(int i = 0; i<this.tamborRevolver.length;i++){ 
		//Tienes que mirar si hay bala y en caso contrario meterla y ademas comprobar que no metas mas de las que te estan pasando
		if(!this.tamborRevolver[i].equals(1)&& contadorCargadas!=numBalas){
			this.tamborRevolver[i] = 1;
			contadorCargadas ++;
		}
	}
	return contadorCargadas;
}


/**
 * Carga el tambor del revólver completamente. Se va recorriendo el tambor desde su posición 0 y se van introduciendo proyectiles en los orificios 
 * que aún no tengan bala (tanto si hay hueco como si hay casquillo). Si en algún orificio ya hay una bala aún sin utilizar, se pasa al siguiente orificio. 
 * Se devolverá el número de balas que efectivamente se han introducido en el tambor.
 * @return 
 */
public int cargar() {
    int balasCargadas=0;
      
     for(int i = 0; i<this.tamborRevolver.length;i++){ 
         
         if(!this.tamborRevolver[posicion].equals(1)){
         this.tamborRevolver[i] = 1;
         balasCargadas ++;
         }
     }
     return balasCargadas;
}

/**
 * Descarga el tambor del revólver completamente. Se vacía completamente el tambor del revólver,
 * tanto de casquillos como de proyectiles sin utilizar.
 * @return 
 */
public int descargar() {

   int cantidadBalasSinUsar=0;   
     
       for(int i = 0; i<this.tamborRevolver.length;i++){ 
            if(this.tamborRevolver[i].equals(1)) {
                 this.tamborRevolver[i]=0;
              cantidadBalasSinUsar++;
            }
       }
      
   return cantidadBalasSinUsar;
}

/**
 * Se dispara el revólver pulsando el gatillo. Si el orificio del tambor que había en ese momento ante el percutor contenía un proyectil completo,
 * se producirá un disparo efectivo. Si el orificio estaba vacío o contenía un casquillo, no se producirá un disparo efectivo. En cuaqluier caso el
 * tambor girará de izquierda a derecha una posición y se colocará el siguiente orificio ante el percutor.
 * @return 
 */

public boolean disparar(){
		Boolean  disparo = false;
		//si hay bala entonces hay disparo avanzo la posición y dejo un casquillo vacio
		if(this.tamborRevolver[posicion].equals(1)){
			disparo = true;
			this.tamborRevolver[posicion] = 0;
			if(posicion< this.tamborRevolver.length ){
				posicion ++;
			}else{
				posicion=0;
			}	
		}
		return disparo;
  }

/**
 * Devuelve una cadena que representa el estado de un revolver. El resultado devuelto representará el contenido del tambor y tendrá la siguiente estructura:
   un inicio de bloque o llave (carácter '{');
   un carácter de tipo '_', 'X' o 'x' por cada orificio del tambor:
   si el orificio está vacío aparecerá el carácter '_' (guion bajo o "subrayado");
   si el orificio contiene una bala completa (no disparada), aparecerá el carácter 'X' (equis mayúscula);
   si el orificio contiene un casquillo (bala disparada), aparecerá el carácter 'x' (equis minúscula);
   un fin de bloque o llave (carácter '}').
   Además, el orificio que se encuentre en ese momento delante del percutor deberá aparecerá encerrado entre corchetes (caracteres '[' y ']'). Así quedará claro el orificio
 * sobre el que va a impactar el percutor la próxima vez que se apriete el gatillo al disparar.

   Aquí tienes un posible ejemplo de salida: { x [X] X X _ _ _ _ }, donde observamos que:

   se trata de un revólver con un tambor de capacidad para ocho proyectiles;
   en el primer orificio hay un casquillo;
   en los orificios segundo, tercero y cuarto hay balas que aún no han sido disparadas;
   los orificios del quinto al octavo se encuentran aún vacíos;
   el percutor se encuentra sobre el segundo orificio.
* 
 * @return 
 */
@Override
    public String toString() {
        StringBuilder resultado = new StringBuilder();
        resultado.append("{");
     for(int i=0;i<tamborRevolver.length;i++){
         
         if( i ==posicion){
             resultado.append("[");
         }
         if(tamborRevolver[i]==null){
            resultado.append("_");
         }else if (this.tamborRevolver[i].equals(0)){
             resultado.append("x");
         }
         if(this.tamborRevolver[i].equals(1)){
             resultado.append("X");
         }
         else if(i ==posicion){
             resultado.append("]");
         }
     }
        
        return resultado.toString();
    }

}
