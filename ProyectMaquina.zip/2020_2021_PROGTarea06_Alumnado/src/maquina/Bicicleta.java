
package maquina;

/**
 * Clase que modela una bicicleta como máquina mecánica con capacidad para desplazarse. No se desea que se puedan crear más subtipos de bicicletas. A la información heredada de la clase MaquinaMecanica, añade 3 atributos:
   Radio de las ruedas. De tipo double, se mide en centímetros.
   Total de kilómetros recorridos desde su fabricación. De tipo double.
   * 
 * @author Cristian Ramos Rodríguez
 */
public final class Bicicleta extends MaquinaMecanica implements Desplazable {
    //El valor por defecto para el radio de la rueda de una bicicleta: 33.0. cm.
    public static final double DEFAULT_RADIO_RUEDA = 33.0;
    
    // El valor mínimo para el radio de una rueda: 17.75 cm.
    public static final double MIN_RADIO_RUEDA =17.75;
    
    //El valor máximo para el radio de una rueda:36.85 cm.
    public static final double MAX_RADIO_RUEDA = 36.85;
    
    //El número máximo de kilómetros que se puede desplazar una bicicleta sin hacer paradas: 200.0 km.
    public static final double MAX_DESPLAZAMIENTO = 200;    
    
    protected double radioRueda;
    protected double totalKilometros;
        
    /**
     * Constructor que crea una bicicleta a partir de los valores recibidos como parámetros para marca y modelo, asignándole como radio el valor por defecto,
     * inicializando el contador de total de kilómetros recorridos a 0.
     * @param marca
     * @param modelo 
     */
    public Bicicleta(String marca, String modelo)  {
        super(marca, modelo);
       
        super.fuerzaMotriz= Fuerza.ANIMAL;
        radioRueda = DEFAULT_RADIO_RUEDA;
        totalKilometros = 0;
        
    }
    
    /**
     * Constructor que crea una nueva bicicleta a partir de los valores recibidos como parámetros para marca, modelo y radio de las ruedas.
     * @param marca
     * @param modelo
     * @param radioRueda
     * @throws IllegalArgumentException 
     */
    public Bicicleta(String marca, String modelo, double radioRueda) throws IllegalArgumentException {
        super(marca,modelo);
        
        this.radioRueda = radioRueda;      
        if(radioRueda < MIN_RADIO_RUEDA || radioRueda > MAX_RADIO_RUEDA) {
            
            throw new IllegalArgumentException ("Error en valor del radio:" + radioRueda + "cm Debe estar comprendido entre" + MIN_RADIO_RUEDA +" cm. y "
                    + MAX_RADIO_RUEDA+" cm.");
          
        }
    }
    
    /**
     * 	
       Método que aumenta el total de kilómetros recorridos por una bicicleta.
     * @param kilometros
     * @throws IllegalArgumentException 
     */
    @Override
    public void desplazar(double kilometros) throws IllegalArgumentException {
        
        if(  kilometros >= 0 || kilometros <= MAX_DESPLAZAMIENTO) {
            totalKilometros =+ kilometros;
        }
        if( kilometros < 0|| kilometros > MAX_DESPLAZAMIENTO ) {
            throw new IllegalArgumentException ("Cantidad de kilómetros negativa o excesiva (Máx: " + MAX_DESPLAZAMIENTO+ " km): " + kilometros +" km.");
        }
    }
    
    /**
     * Método que devuelve el radio de la rueda de la bicicleta que lo invoca.
     * @return radioRueda
     */
    public double getRadioRuedas() {
        return this.radioRueda;
    }
    
    /**
     * Método que devuelve el total de kilómetros que la bicicleta ha recorrido desde su fabricación.
     * @return totalKilometros
     */
    @Override
    public double getTotalKilometrosRecorridos() {
        return this.totalKilometros;
    }
    
    /**
     * Método que devuelve el total de kilómetros que ha recorrido la bicicleta sin repostar.
     * @return totalKilometros
     */
    @Override
    public double getKilometrosSinRepostar() {
        return this.kilometrosSinRepostar;
    }
    
    /**
     * Método que devuelve la representación como String de una bicicleta.
     * @return La representación como String de una bicicleta, con el formato { Marca: XXX; modelo: YYY; NS: ZZZ; Fuerza Motriz: WWW; Radio: VVV; Kilómetros: UUU }
     */
    @Override
        public String toString() {
            String toStringSuper = super.toString();
            return String.format("%10s; Radio: %f  Kilómetros: %f }",
               toStringSuper.substring(0, toStringSuper.length() - 2),
               this.getRadioRuedas() , this.getTotalKilometrosRecorridos());
        }
}
