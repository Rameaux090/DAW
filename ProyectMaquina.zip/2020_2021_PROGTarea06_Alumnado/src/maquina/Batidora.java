
package maquina;

import java.util.Arrays;

/**
 * Clase Batidora, que representa una batidora como tipo de máquina eléctrica enchufable (pero no recargable).
   Los objetos de esta clase modifican y detallan ciertos aspectos del funcionamiento de una máquina eléctrica genérica, pero no contienen ningún atributo adicional.
 * @author Cristian Ramos Rodríguez.
 */
public class Batidora extends MaquinaElectrica implements Enchufable {
   public static final int DEFAULT_POTENCIA_BATIDORA = 700;
   public static final int DEFAULT_VOLTAJE_BATIDORA = 230;
   
   private final static String[][] LISTA_PAISES_COMPATIBLES = {
        {"Japón", "Corea"}, //para 110 v.
        {"USA"}, //para 120 v.
        {"China"},//para 220 v.
        {"España", "Alemania", "Francia", "Bélgica"}//para 230 v.
    };
   /**
    * Crea un nuevo objeto de tipo Batidora, con los valores indicados como parámetros para marca y modelo, con un voltaje estándar de 230 V. y una potencia estándar de 700 W.
    * @param marca
    * @param modelo
    * @param voltaje
    * @param potenciaElectrica
    * @throws IllegalArgumentException 
    */
   public Batidora(String marca, String modelo,int voltaje , double potenciaElectrica) throws IllegalArgumentException {
       super(marca,modelo);
      
       if(voltaje != 110 || voltaje != 120 || voltaje != 220 || voltaje != 230) {
           throw new IllegalArgumentException (" Error en voltaje:" + voltaje +" (Valores válidos: Japón/Corea: 110v.; USA: 120v.; China: 220v.; España/Alemania/Francia/Bélgica: 230v.)");
       }
       
       if(potenciaElectrica  !=500 ||potenciaElectrica  !=600 ||potenciaElectrica  !=700 ||potenciaElectrica  !=800 ||potenciaElectrica  !=1000 || potenciaElectrica  !=1200 ||
               potenciaElectrica  !=1500) {
           throw new IllegalArgumentException("Error en potencia eléctrica:" + potenciaElectrica +" (Valores válidos: 500/600/700/800/1000/1200/1500 w.).");
       }
   }
   
   /**
    * Método que permite obtener un array de String con la lista de países en los que el voltaje es compatible con el de la Batidora.
    * @return El listado de países en los que el voltaje es compatible con el de la Batidora, con formato de array de String.
    */
   @Override
   public String[] getPaisesCompatibles() {
      return
   }
   
   /**
    * Metodo que permite obtener el voltaje de la batidora.
    * @return el numero de voltaje en ese momento.
    */
   @Override
   public int getVoltaje() {
       return this.voltaje;
   }
   
   /**
    *Método que permite obtener la representación como String de una Batidora, con el formato: { Marca: XXX; modelo: YYY; NS: ZZZ; Voltaje: WWW v.; Potencia: VVVV W.; Países Compatibles: WWW}
    * @return La representación como String de una Batidora.
    */
    @Override
        public String toString() {
            String toStringSuper = super.toString();
            return String.format("%s; Paises Compatibles: %s}",
                toStringSuper.substring(0, toStringSuper.length() - 2),
               Arrays.toString(this.getPaisesCompatibles()));
        }
}
