package tarea04;

import java.util.Arrays;

public class Ejercicio05 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes

        // Variables de entrada 
        String[] listaCombinaciones = { /* Elementos del array */
           };

        // Variables de salida

        // Variables auxiliares
        

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("LOTERÍA PRIMITIVA");
        System.out.println("-----------------");
        // En este caso no hay entrada de datos pues los tenemos en un array "fijo" en el programa
        // En un caso real ese array se cargaría de un archivo o por la red

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // 2. Definimos un array de MAX_SORTEOS filas y 6 columnas

        // 3. Expresión regular esperada: "primitiva" seguido de 12 dígitos

        // 4. Recorrer el array listaCombinaciones

                // 4.1. Si el patrón coincide lo mostramos por consola

                // 4.2. Obtener los números que empiezan después de la palabra "primitiva"


                    // Comprobar si son números válidos para la primtiva (está entre 0 y 49)

                    // Si no salió ningún número no válido entonce el sorteo fue válido
                    // a no ser que haya números repetidos
                    
                    // Comprobar repetidos. Si hay números repetidos la combinación no es válida


        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println ();
        System.out.println("RESULTADO: SORTEOS VÁLIDOS");
        System.out.println("--------------------------");

        // Escribir los sorteos válidos

    }

}
