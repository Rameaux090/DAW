
package tarea04;

import java.util.Scanner;

public class Ejercicio03 {
    
    public static void main(String[] args) {
        
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes

        // Variables de entrada

        // Variables de salida
        
        // Variables auxiliares

        // Clase Scanner para petición de datos por teclado
        Scanner teclado = new Scanner(System.in);
        
        //----------------------------------------------
        //     Entrada de datos + Procesamiento
        //----------------------------------------------
        System.out.println("SISTEMAS DE NUMERACIÓN");
        System.out.println("----------------------");
        
        // 1. Creación del StringBuilder: cadena donde se irán almacenando los resultados válidos
        
        // Iterar para leer números e ir acumulando el valor

            // 2. Lectura de teclado de un número + 3. Limpieza del texto leído

            
            // Conversión del número

            
                // 4. Comprobamos si es un número egipcio

                    // 4.1. En caso afirmativo efectuamos la conversión

                    // 4.2. Añadimos al resultado el texto con el tipo de conversión
                
                // 5. Comprobamos si es un número binario
                
                    // 5.1. En caso afirmativo efectuamos la conversión

                    // 5.2. Añadimos al resultado el texto con el tipo de conversión
                    
                // 6. Comprobamos si es un número hexadecimal
                
                    // 6.1. En caso afirmativo efectuamos la conversión

                    // 6.2. Añadimos al resultado el texto con el tipo de conversión

                // 7. En cualquier otro caso, hay que intentar convertirlo a entero.

                // 7.1. Añadimos al resultado el texto con el tipo de conversión

                
                // Añadir a la salida el número recibido asi como su conversión en formato "(xx->yy)"
                
                
            // 8. Control ante un posible número con formato no válido

            
        // 9. Se seguirán leyendo números hasta que el usuario tecle "fin" o "end"    
 
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        // 10. Mostramos los resultados
        System.out.println();
        System.out.println("RESULTADOS: CONVERSIÓN EN DIFERENTES SISTEMAS DE NUMERACIÓN") ;
        System.out.println("-----------------------------------------------------------") ;
    }
    
           
}
