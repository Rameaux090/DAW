package tarea04;

import java.util.Scanner;


public class Ejercicio01 {

    public static void main(String[] args) {
        
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes

        // Variables de entrada

        // Variables de salida
        
        // Variables auxiliares

        // Clase Scanner para petición de datos por teclado
        Scanner teclado = new Scanner(System.in);
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("MEZCLA DE CADENAS");
        System.out.println("-----------------");
        
        // Leer primera cadena controlando el tamaño que sea de al menos 5 caracteres

        
        // Leer primera cadena controlando el tamaño que sea de al menos 5 caracteres
        
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------



        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO: CADENAS MEZCLADAS");
        System.out.println("----------------------------");

    }
    
}
