package tarea04;


public class Ejercicio02 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes

        // Variables de entrada
        
        // Array de cadenas a procesar.
        // Podríamos considerarlo de "entrada" aunque en este caso es "fijo", ya que 
        // estamos simulando lo que nos llegaría por la red.
        String[] datos = { /* Elmentos del array */
                        } ;

        
        // Variables de salida
        StringBuilder cadenaResultado;
        
        // Variables auxiliares

        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("PEDIDOS DE FARMACIAS");
        System.out.println("--------------------");
        // En este caso no hay entrada de datos pues los tenemos en un array "fijo" en el programa
        // En un caso real ese array se cargaría con valores obtenidos a través de la red
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------


        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO: PEDIDOS VÁLIDOS");
        System.out.println("--------------------------");

        // Mostrar por pantalla el resultado final
        
    }
    
}