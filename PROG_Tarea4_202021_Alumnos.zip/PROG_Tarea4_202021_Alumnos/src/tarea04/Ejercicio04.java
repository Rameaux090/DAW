package tarea04;

import java.util.Scanner;

/**
 * Ejercicio 4: butacas de un teatro.
 */
public class Ejercicio04 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes

        // Variables de entrada

        // Variables de salida
        double[][] arrayButacas;
        
        // Variables auxiliares

        // Clase Scanner para petición de datos por teclado
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("BUTACAS DE UN TEATRO");
        System.out.println("--------------------");
        
        // 1. Solicitamos por teclado el número de butacas

        // 2. Reservamos espacio para el array

        // 2.1. Reservamos espacio para la primera dimensión (cantidad de filas)
        
        // 2.2. Resevamos espacio para cada fila (no es una tabla "regular")
        
        // 3. Mostramos por pantalla el contenido del array que se acaba de crear
        // usando Arrays.deepToString
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        // Rellenamos el array con los precios

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO: ESTRUCTURA DE BUTACAS Y PRECIOS POR FILAS");
        System.out.println("----------------------------------------------------");

    }

}
