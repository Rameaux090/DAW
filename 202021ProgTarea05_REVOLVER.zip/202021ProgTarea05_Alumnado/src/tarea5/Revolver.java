package tarea5;
import libtarea5.Audio;

// ------------------------------------------------------------
//                   Clase Revolver
// ------------------------------------------------------------
/**
 * Clase que representa un <strong>revolver</strong>.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 * @author Cristian Ramos Rodríguez.
 */
public class Revolver {



}
