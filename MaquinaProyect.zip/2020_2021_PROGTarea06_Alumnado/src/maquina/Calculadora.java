
package maquina;

/**
 *Clase que permite representar una Calculadora como un tipo especial de Máquina Eléctrica que es recargable, con la particularidad de que en este caso,
 * su batería son pilas. A los atributos heredados de la clase MaquinaElectrica, añade el atributo tipoPila, que tomará su valor de un tipo enumerado TipoPila,
 * siendo válidos para la Calculadora solo algunos de los valores que incluye ese enumerado (pilas AA de 1,5 v. y pilas botón CR1025 de 3 v.
 * @author Cristian Ramos Rodríguez.
 */
public class Calculadora extends MaquinaElectrica implements Recargable{
     /**
     * Se establece que toda calculadora debe tener las pilas adecuadas para que cuando se le repongan permitan su uso durante 100 horas. Valor: 100
     */
    public static final int HORAS_DE_USO = 100;
    /**
     * Tipo por defecto para la pila de la calculadora: AA_1_5V
     */
    public static final TipoPila DEFAULT_TIPO_PILA = TipoPila.AA_1_5V;
    /**
     * Por defecto la calculadora estará sin pilas, así que se considera que la pila está agotada, ya que necesita que se le introduzca una nueva pila. 
     * Valor por defecto: true
     */
    public static final boolean DEFAULT_PILA_AGOTADA = true;
    
    protected TipoPila tipoPila ;
    protected int horasDeUso;
    protected boolean pilaAgotada;
   
    
    /**
     * Constructor que permite asignar, además de la marca, modelo y tipo de pila de la calculadora, un "estado de la pila",
     * indicando si lleva o no una pila con carga para funcionar. Las horas de uso se inicializan a 0.
     * @param marca
     * @param modelo
     * @param tipoPila
     * @param pilaAgotada
     * @throws IllegalArgumentException
     * @throws NullPointerException 
     */
    public Calculadora(String marca, String modelo,TipoPila tipoPila, boolean pilaAgotada) throws IllegalArgumentException,NullPointerException {
            super(marca,modelo);  
            this.tipoPila =tipoPila;         
             if(tipoPila == TipoPila.AA_1_5V || tipoPila == TipoPila.BOTON_CR1025_3V) {
                  this.tipoPila = tipoPila;
                  this.pilaAgotada = false;
                  this.horasDeUso = 0;
                }
                if (tipoPila ==null) {
                     throw new NullPointerException ("Error en tipo de pila: "+tipoPila + ". El tipo de pila no puede ser nulo.");
                }
                if(tipoPila != TipoPila.AA_1_5V || tipoPila != TipoPila.BOTON_CR1025_3V) {
                    throw new IllegalArgumentException("Error en tipo de pila:" +tipoPila+". Las calculadoras solo admiten pilas de tipo "+TipoPila.AA_1_5V +" y " +
                            TipoPila.BOTON_CR1025_3V);
                }
               
            
     }
    
    /**
     * Método Constructor que crea una nueva calculadora de una marca, modelo y tipo de pila. El atributo pilaAgotada recibirá el valor por defecto.
     * El atributo horasDeUso recibirá el valor 0, puesto que la calculadora aún está sin usar.
     * @param marca
     * @param modelo
     * @param tipoPila 
     */
    public Calculadora(String marca, String modelo, TipoPila tipoPila)  throws IllegalArgumentException,NullPointerException {
       super(marca,modelo); 
       this.tipoPila =tipoPila;
       this.pilaAgotada = Calculadora.DEFAULT_PILA_AGOTADA;
       this.horasDeUso = 0;
    }
    
    /**
     * Método que permite cargar una calculadora. Al tratarse de calculadoras solo de pilas, la operación consistirá en reponer las pilas usadas con pilas nuevas,
     * actualizando convenientemente el estado de la pila, asignando el valor false al atributo pilaAgotada y reiniciando las horas de uso a cero.
     */
    @Override
    public void cargar() {
        this.pilaAgotada =false;
        this.horasDeUso =0;
    }
    
    /**
     * Método que devuelve el número de horas de uso restantes para la calculadora, tras haber sido usada el número de horas que se recibe como parámetro.
     * Se estima que todas las calculadoras vienen equipadas con las pilas necesarias para un mmismo número de horas de funcionamiento, expresado por la constante
     * de clase HORAS_DE_USO.
     * @param horas
     * @return 
     */
    @Override
    public double usarBateria​(double horas) {
       this.horasDeUso = (int) horas;
       double horasRestantes = (HORAS_DE_USO - this.horasDeUso);
       if(this.pilaAgotada == false && this.horasDeUso < horasRestantes) {
           this.horasDeUso =(int) + horas;
           horasRestantes = horasRestantes - this.horasDeUso;
       }
       if(this.pilaAgotada == true && this.horasDeUso >= horasRestantes) {
           this.pilaAgotada = false;
           horasRestantes = 0;
       }
       return horasRestantes;
        
    }
    /**
     * Método que devuelve la representación como String de una Calculadora.
     * @return La representación como String de una Calculadora con el formato { Marca: XXX; modelo: YYY; NS: ZZZ; Voltaje: WWW v.; Potencia: VVVV W; Tipo de pila: UUU; Horas de uso restantes: }  
     */
     @Override
        public String toString() {
            String toStringSuper = super.toString();
            return String.format("%s; Tipo de Pila: %-10s  Horas de uso restantes: %f }",
                toStringSuper.substring(0, toStringSuper.length() - 2),
               this.tipoPila,this.usarBateria(potenciaElectrica));
        }
}
