
package maquina;

/**
 * Clase abstracta para representar una <strong>Máquina</strong>. Toda máquina va a disponer de tres atributos: numeroDeSerie, marca y modelo,
 * cuyo valor no va a cambiar una vez asignados. El número de serie será un número entero secuencial, que usaremos para cualquier
 * tipo de máquina que fabriquemos. La marca y el modelo son solo dos cadenas de caracteres. Dispondrá de métodos para consultar 
 * estos atributos, pero no para modificarlos, ya que no estará permitido una vez que se les asigna un valor al fabricar la máquina.

 * @author Cristian Ramos Rodríguez.
 */
public abstract class Maquina {
    protected final  String marca;
    protected final String modelo;
    protected final int numeroSerie;
    public static int cantidadDeMaquinasFabricadas;
    private static int siguienteNumSerie = 0;
    
    /**
     * Constructor que crea un objeto de tipo Maquina de una marca y modelo determinados.
     * @param marca
     * @param modelo 
     */
    
    public Maquina (String marca,String modelo) {
        /**
         * Realizamos los valores de la marca que podran ser o null o vacio.
         */
        this.marca = 
                (marca == null || marca.isEmpty()) ? 
                 marca : marca;
        /**
         * Realizamos los valores del modelo que pueden ser null o vacio.
         */     
        this.modelo = 
                (modelo == null || modelo.isEmpty()) ? 
                 modelo : modelo;
        /**
         * Creamos el atributo numeroSerie de manera incremental.
         */
        this.numeroSerie = Maquina.siguienteNumSerie++;
        Maquina.cantidadDeMaquinasFabricadas++;
     
    }
    /**
     * Permite consultar la marca del objeto que lo invoca.
     * @return marca
     */
    protected String getMarca() {
        return marca;
    }
    /**
     * Permite consultar el modelo del objeto que lo invoca.
     * @return modelo
     */
    protected String getModelo() {
        return modelo;
    }
    /**
     * Permite consultar el número de serie del objeto que lo invoca.
     * @return numeroSerie
     */
    protected int getNumeroDeSerie() {
        return this.numeroSerie;
    }
    /**
     * Método para obtener el total de máquinas fabricadas.
     * @return CantidadDeMaquinasFabricadas.
     */
    public static int getCantidadDeMaquinasFabricadas() {
        return Maquina.cantidadDeMaquinasFabricadas;
    }
    /**
     * 
     * @return 
     */
    @Override
      public String toString() {
        return String.format("{ Marca: %-10s; modelo: %-10s; NS: %-4d }",
                this.getMarca(),
                this.getModelo(),
                this.getNumeroDeSerie());
    }
     
}



