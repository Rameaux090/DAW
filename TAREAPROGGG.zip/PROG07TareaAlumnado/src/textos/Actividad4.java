package textos;

import cesar.TextoEncriptado;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class Actividad4 {
 
    
    /**
     * Método principal
     *
     * @param args argumentos de la línea de ordenes
     */
    public static void main(String[] args) {
         try {
             /**
              * Leemos el fichero .txt para almacenarlo en el buffer y poder comenzar su lectura
              * en una lista.
              */
            FileReader leerTexto = new FileReader("texto_claro_salida.txt");
            BufferedReader buffer=new BufferedReader(leerTexto);
            List <TextoEncriptado> listado = new ArrayList <> ();        
            /**
             * Leemos la primera linea del fichero y creamos un objeto TextoEncriptado con la frase adecuada.
             */
            String cadena = buffer.readLine();
            TextoEncriptado fraseUno = new TextoEncriptado(cadena,1);
            listado.add(fraseUno);
          
            String cadenaDos = buffer.readLine();
            TextoEncriptado fraseDos = new TextoEncriptado(cadenaDos,2);
            listado.add(fraseDos);
        
            String cadenaTres = buffer.readLine();
            TextoEncriptado fraseTres = new TextoEncriptado(cadenaTres,3);
            listado.add(fraseTres);
            
            String cadenaCuatro = buffer.readLine();
            TextoEncriptado fraseCuatro = new TextoEncriptado(cadenaCuatro,4);  
            listado.add(fraseCuatro);
            
            String cadenaCinco = buffer.readLine();
            TextoEncriptado fraseCinco = new TextoEncriptado(cadenaCinco,5);
            listado.add(fraseCinco);
            
            /**
             * Cerramos buffer.
             */
           buffer.close();
           int contador =0;
           String cadenaFinal ="";
            System.out.println("CONTENIDO DEL ARCHIVO DE TEXTO");
            System.out.println("------------------------------");
            /**
             * Comenzamos la lectura del listado recorriendola para almacenarlo todo en una cadena tipo String e imprimimos por pantalla el resultado final.
             */
          for(TextoEncriptado lista : listado) {
              contador++;
               if(contador ==1) {                        
                       cadenaFinal += " OPCION " + fraseUno.getClave()+ " - "+ cadena.split(" ").length + " palabras " + fraseUno.getTexto() +"\n";
                     }
               if(contador ==2) {                       
                         
                       cadenaFinal += " OPCION " + fraseDos.getClave()+ " - "+ cadenaDos.split(" ").length + " palabras " + fraseDos.getTexto() +"\n";
                     }
               if(contador ==3) {                       
                         
                       cadenaFinal += " OPCION " + fraseTres.getClave()+ " - "+ cadenaTres.split(" ").length + " palabras " + fraseTres.getTexto() +"\n";
                     }
               if(contador ==4) {                       
                         
                       cadenaFinal += " OPCION " + fraseCuatro.getClave()+ " - "+ cadenaCuatro.split(" ").length + " palabras " + fraseCuatro.getTexto() +"\n";
                     }
               if(contador ==5){                       
                         
                       cadenaFinal += " OPCION " + fraseCinco.getClave()+ " - "+ cadenaCinco.split(" ").length + " palabras " + fraseCinco.getTexto() +"\n";
                     }
          }
          /**
           * Procedemos a crear un nuevo archivo .dat en el que le escribiremos los datos del listado anterior.
           */
            ObjectOutputStream escribiendoFichero = new ObjectOutputStream( 
            new FileOutputStream("texto_encriptado_entrada.dat") );
            escribiendoFichero.writeObject(listado);
            escribiendoFichero.close();
          
            System.out.println(cadenaFinal);
            
        } catch (FileNotFoundException ex) {
          System.out.println("Error: no se ha podido cerrar el archivo.");
        } catch (IOException ex) {
           System.out.println("Error: no se ha podido cerrar el archivo.");
        }
    }
    }
