package textos;

import cesar.TextoEncriptado;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

public class Actividad2 {
 
    
    /**
     * Método principal
     *
     * @param args argumentos de la línea de ordenes
     */
    public static void main(String[] args) {
        try {
            /**
             * Obtenemos los datos del fichero .dat y creamos una lista de tipo TextoEncriptado para
             * almacenar todo lo correspondiente dentro de esta.
             */
            FileInputStream fichero = new FileInputStream("texto_encriptado_entrada.dat");
            ObjectInputStream entrada = new ObjectInputStream(fichero);          
            List <TextoEncriptado> listado = new ArrayList <> ();         
            listado =  (List <TextoEncriptado>) entrada.readObject();
             
            String cadenaFinal = "";
            /**
             * Generamos un archivo .txt para almacenar el texto del objeto.
             */
            FileWriter ficheroTexto = new FileWriter("texto_claro_salida.txt");
            BufferedWriter buffer = new BufferedWriter(ficheroTexto);      
             
              for(TextoEncriptado cadena : listado) {
                  cadenaFinal += cadena.descifradoCesar() +"\n";
              }
               buffer.write(cadenaFinal);
                    buffer.close();
                            entrada.close();            
          
        } catch (FileNotFoundException ex) {
          System.out.println("Error: no se ha podido cerrar el archivo.");
        } catch (IOException ex) {
           System.out.println("Error: no se ha podido cerrar el archivo.");
        } catch (ClassNotFoundException ex) {
          System.out.println("Error: no se ha podido cerrar el archivo.");
        } 
            
        }
    }
