package textos;

import cesar.TextoEncriptado;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

public class Actividad1 {
    public static void main(String[] args)   {

        try {
            /**
             * Obtenemos los datos del archivo .dat
             */
             FileInputStream fichero = new FileInputStream("texto_encriptado_entrada.dat");
             /**
              * Leemos el contenido del fichero y lo guardamos en una variable InputStream.
              */
             ObjectInputStream entrada = new ObjectInputStream(fichero);
             /**
              * Creamos una lista de tipo TextoEncriptad y almacenamos los datos del fichero .dat
              */
             List <TextoEncriptado> listado = new ArrayList <> ();         
             listado =  (List <TextoEncriptado>) entrada.readObject();        
                  String cadenaFinal = "";
         
              System.out.println("CONTENIDO DEL ARCHIVO DE TEXTO");
              System.out.println("-----------------------------");
               System.out.println("Total de oraciones leidas: "+ listado.size());
               
                String contarFraseUno ="";
                String contarFraseDos ="";
                String contarFraseTres ="";
                String contarFraseCuatro ="";
                String contarFraseCinco ="";
                int contador =0;
                /**
                 * Recorremos la lista para ir añadiendole y desencriptando todo los datos.
                 */
               for(TextoEncriptado cadena : listado) {
                   
                   cadena.descifradoCesar();
                     contador++;
                     
                     if(contador ==1) {
                         contarFraseUno += cadena.getTexto();
                         
                       cadenaFinal += " OPCION " + cadena.getClave()+ " - "+ contarFraseUno.split(" ").length + " palabras " + cadena.getTexto()+"\n";
                     }
           
                     if(contador ==2) {
                       contarFraseDos += cadena.getTexto();
                     cadenaFinal +=  " OPCION " + cadena.getClave()+ " - "+ contarFraseDos.split(" ").length+ " palabras " + cadena.getTexto()+"\n";
                     
                     }
                     if(contador ==3) {
                       contarFraseTres += cadena.getTexto();
                     cadenaFinal += " OPCIÓN " + cadena.getClave() + " - "+ contarFraseTres.split(" ").length+ " palabras " + cadena.getTexto()+"\n";
                     
                     }
                      if(contador ==4) {
                        contarFraseCuatro += cadena.getTexto();
                     cadenaFinal += " OPCIÓN " + cadena.getClave() + " - "+ contarFraseCuatro.split(" ").length+ " palabras " + cadena.getTexto()+"\n";
                     
                     }
                      else if (contador ==5) {
                        contarFraseCinco += cadena.getTexto();
                     cadenaFinal += " OPCIÓN " + cadena.getClave() + " - "+ contarFraseCinco.split(" ").length+ " palabras " + cadena.getTexto()+"\n";
                     
                     }
                    
                 }  
            /**
             * Cerramos buffer , cerramos el archivo.
             */
               entrada.close();
            /**
             * Mostramos el resultado final.
             */
            System.out.println(cadenaFinal);
        } catch (FileNotFoundException ex) {
               System.out.println("Error: no se ha podido cerrar el archivo.");
        } catch (IOException | ClassNotFoundException ex) {
              System.out.println("Error: no se ha podido cerrar el archivo.");
        }

    }
}
