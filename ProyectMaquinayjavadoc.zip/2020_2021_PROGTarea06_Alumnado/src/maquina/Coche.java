
package maquina;

/**
 *Calse abtracta para modelar un Coche como máquina mecánica desplazable. Define un parámetro combustibleUsado, que puede tomar los valores del tipo enumerado TipoCombustible.
 * Valores válidos son GASOLINA, DIESEL O ELECTRICIDAD. Como atributos, añade a los heredados por ser una subclase de máquina mecánica los siguientes:
  combustibleUsado. Es el tipo de combustible que usa el Coche.
  kilometrosSinRepostar. Es la distancia recorrida en km. por el Coche desde que se repostó por última vez.
  kilometrosTotalesRecorridos. Es la distancia recorrida en km. por el Coche desde su fabricación. 
  * 
 * @author Cristian Ramos Rodríguez.
 */
public abstract class Coche extends MaquinaMecanica implements Desplazable {
    public static final double MAX_DESPLAZAMIENTO = 1500.0;
        /**
         * Constructor para crear una máquina mecánica a partir de la marca, el modelo y la fuerza motriz recibidos como parámetros.
         * @param marca
         * @param modelo
         * @param fuerzaMotriz
         * @throws NullPointerException
         * @throws IllegalArgumentException 
         */
    public Coche(String marca, String modelo, Fuerza fuerzaMotriz) throws NullPointerException,IllegalArgumentException {
        super(marca, modelo, fuerzaMotriz);
            this.kilometrosSinRepostar = 0;
            this.kilometrosTotalesRecorridos =0;
                if(fuerzaMotriz == null) {
                    throw new NullPointerException ("Error, Fuerza motriz no válida:" + fuerzaMotriz);
                }
                if( fuerzaMotriz != Fuerza.COMBUSTIBLE) {
                    throw new IllegalArgumentException("Valor de Fuerza motriz incompatible con un Coche: " + fuerzaMotriz);
                 }
      
    }
    /**
     * Método que realiza el repostaje de un Coche. Dada la simplicidad del modelo, simplemente pone a cero el contador de kilómetros sin repostar.
     */
    public void repostar() {
         this.kilometrosSinRepostar = 0;
    }
    /**
     * Método que devuelve el total de kilómetros que se han recorrido desde el último respostaje del Coche.
     * @return El total de kilómetros que ha recorrido este Coche hasta el momento.
     */
    @Override
    public double getKilometrosSinRepostar() {
        return this.kilometrosSinRepostar;
    }
    
    /**
     * Método que devuelve el total de kilómetros que se han recorrido desde la fabricación del coche. Este método va a estar disponible para todos los coches, sin posibilidad de redefinirlo.
     * @return El total de kilómetros que ha recorrido este coche desde su fabricación.
     */
    @Override
    public final double getTotalKilometrosRecorridos() {
        return this.kilometrosTotalesRecorridos;
    }
    /**
     * Método que establece una manera genérica de desplazar cualquier Coche. Incrementará el número de kilómetros recorridos por el coche en la cantidad indicada
     * por el parámetro kilometros.
     * No se va a permitir desplazamientos negativos ni mayores que el valor expresado por MAX_DESPLAZAMIENTO (1500.0 km.) en ningún Coche.
     * En caso de que el parámetro reibido sea válido,se producirá el desplazamiento y se actualizará el total de kilómetros recorridos por el Coche y 
     * el total de kilómetros sin repostar.
     * 
     * @param kilometros
     * @throws IllegalArgumentException 
     */
    @Override
    public void desplazar​(double kilometros) throws IllegalArgumentException {
        this.kilometrosSinRepostar =+ kilometros;
        this.kilometrosTotalesRecorridos =+ kilometros;
        if(kilometros < 0 || kilometros > MAX_DESPLAZAMIENTO) {
            throw new IllegalArgumentException("Cantidad de kilómetros negativa, o excesiva para un Coche (Máx:" + MAX_DESPLAZAMIENTO +"): " + kilometros +" km.");
        }
         
    }
    /**
     * 
     * @return 
     */
    public abstract TipoCombustible getTipoCombustible();
    
    /**
     * Método que devuelve la representación como String de un Coche.
     * @return La representación como String de un Coche con el formato 
     * { Marca: XXX; modelo: YYY; NS: ZZZ; Fuerza Motriz: WWW; Combustible: VVV; Km. sin repostar: UUU; Kilometraje: TTT }
     */
     @Override
        public String toString() {
            String toStringSuper = super.toString();
            return String.format("%s; Combustible: %-10ds Km sin respostar: %s }",
                toStringSuper.substring(0, toStringSuper.length() - 2),
               this.getTipoCombustible(), this.getKilometrosSinRepostar());
        }
}
