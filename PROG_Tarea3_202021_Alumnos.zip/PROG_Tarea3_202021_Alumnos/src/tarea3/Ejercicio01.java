package tarea3;

import libtarea3.ComeCocos;
import libtarea3.Direccion;

/**
 * Ejercicio 1: esqueleto para escribir las instrucciones que le demos al comecocos
 * 
 * @author xxx
 */
public class Ejercicio01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // 1. Declarar una variable referencia a objetos instancia de la clase ComeCocos
        // (variable miComeCocos).


        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("MOVIENDO LOS COMECOCOS");
        System.out.println("----------------------");
        // 2. Instanciar un objeto de la clase ComeCocos ubicado en la posición x=120, y=215 
        // y mirando hacia el ESTE.
        // Asignar a la variable anterior la referencia al objeto recién creado.


        //----------------------------------------------
        //       Procesamiento + Salida de Resultados
        //----------------------------------------------
        // 3. Mostrar por pantalla el estado  inicial del objeto.
        // Dispones para ello del método toString.
        
        // 4. Hacer avanzar 10 posiciones al comecocos.
       
        
        // 5. Mostrar por pantalla el estado del comecocos.

        
        // 6. Girar hacia la derecha el comecocos.

        
        // 7. Hacer avanzar otras 10 posiciones al comecocos.

        
        // 8. Mostrar por pantalla el estado del comecocos.

        
        // 9. Hacer avanzar 25 posiciones al comecocos.
        
        
        // 10. Mostrar por pantalla el estado del comecocos.

        
        // 11. Girar hacia la izquierda el comecocos.

        
        //12. Volver a girar hacia la izquierda el comecocos.

        
        // 13. Hacer avanzar 20 posiciones al comecocos.

        
        // 14. Mostrar por pantalla el estado del comecocos.

        
        // 15. Hacer avanzar 45 posiciones al comecocos.

        
        // 16. Mostrar por pantalla el estado del comecocos.

        
        // 17. Obtener la dirección a la que está mirando el comecocos y 
        // convertirla a grados con la herramienta que proporciona la clase 
        // (método estático direccionAGrados).
        
    }
    
}
